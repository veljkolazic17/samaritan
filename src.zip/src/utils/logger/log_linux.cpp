#ifdef TARGET_LINUX
#include <utils/logger/log.hpp>

void TTYOutput(const char* message)
{

}

#endif