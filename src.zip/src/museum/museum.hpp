#pragma once
//clone https://github.com/nothings/stb.git
#include <museum/stb/stb_image.h>
#ifndef SM_USE_MUSEUM_STB
#define SM_USE_MUSEUM_STB 1
#endif // !SM_USE_MUSEUM_STB